tailwind.config = {
    theme: {
        extend: {
            colors: {
                primary: '#2563EB',
                secondary: '#1E40AF',
                accent: '#FACC15',
                dark: '#1E293B'
            }
        }
    }
}